package com.mvc;

import com.mvc.dao.TaskRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
//@EnableJpaRepositories(basePackageClasses = TaskRepository.class)
//@EntityScan(basePackageClasses = com.mvc.Entities.Task.class)
//@ComponentScan(basePackages = {"com.springboot.*"})
public class MainTaskManagerApp {
    public static void main(String[] args) {
        SpringApplication.run(MainTaskManagerApp.class, args);
    }
}
