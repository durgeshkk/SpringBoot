package com.mvc.controller;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.mvc.Services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mvc.Entity.Task;

@RestController
public class TaskController {
   
    @Autowired
    create_Task create_task;

    @Autowired
    view_Task view_task;
    
    @Autowired
    update_Task update_task;
    
    @Autowired
    delete_Task delete_task;

    @PostMapping("/api/request/createTask")
    public void CreateTask(@RequestBody Task tasksEntitiesss){
        create_task.data_saved(tasksEntitiesss);
    }
    
    @PostMapping("/api/request/updatetask")
    public void UpdateTask(@RequestBody Task tasksEntitiesss){
        update_task.updateById(tasksEntitiesss);
    }

    private void displayTaskAttributes(Task task) {
        System.out.println("ID: " + task.getId());
        System.out.println("Cntr: " + task.getCntr());
        System.out.println("Title: " + task.getTitle());
        System.out.println("Title Description: " + task.getTitle_description());
        System.out.println("Due Date: " + task.getDue_date());
        System.out.println();
    }

    @PostMapping("/api/request/viewdb")
    public void ViewDB() throws JsonProcessingException {
        List<Task> allEntities = view_task.getAllEntities();
//        Declarative Programming
//        allEntities.forEach(this::displayTaskAttributes);

//        Functional Programming + JSON Serialize
//        Add Dependency : com.fasterxml.jackson.core/jackson-databind/2.12.4
//        This will not be able to de/serialize Date
        /*
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            // Serialize the list to JSON format
            String json = objectMapper.writeValueAsString(allEntities);
            System.out.println(json);
        } catch (Exception e) {
            e.printStackTrace();
        }
         */

//        Dependency for Date : com.fasterxml.jackson.datatype/jackson-datatype-jsr310/2.10.4
        ObjectMapper objectMapper = new ObjectMapper();

//         registerModule() adds support for Java 8 date and time types, like LocalDate, enabling the serialization and deserialization of these types.
        objectMapper.registerModule(new JavaTimeModule());
        // Serialize LocalDate to JSON
        String json = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(allEntities);
        System.out.println(json);

//        To print all tasks separately
        // Deserialize JSON to List<Task>
//        List<Task> deserializedTasks = objectMapper.readValue(json, new TypeReference<List<Task>>() {});
//        for (Task task : deserializedTasks) {
//            System.out.println(task);
//        }
    }

    @PostMapping("/api/request/viewbyid")
    public void ViewByID(@RequestBody HashMap<String,Long> bdy){
        Optional<Task> view_taskById = view_task.getById(bdy.get("id"));
        if(view_taskById.isPresent()) {
            System.out.println(view_taskById);
        }
    }
    
    @PostMapping("/api/request/viewBeforeDueDate")
    public void ViewBeforeDueDate(@RequestBody HashMap<String,LocalDate> bdy){
        List<Task> beforeDueDate = view_task.getBeforeDueDate(bdy.get("localDate"));
//        Can print it using Object Mapper as well
        System.out.println(beforeDueDate);
    }

    @PostMapping("/api/request/viewTitlePatternMatching")
    public void ViewTitlePatternMatching(@RequestBody HashMap<String,String> bdy){
        List<Task> patternMatching = view_task.getTitlePatternMatching(bdy.get("pattern"));
        System.out.println(patternMatching);
    }

    @PostMapping("/api/request/deleteAll")
    public void DeleteAll(){
        delete_task.deleteAll();
    }

    @PostMapping("/api/request/deleteId")
    public void DeleteByIntId(@RequestBody HashMap<String,Long> bdy){
        delete_task.deleteByIntId(bdy.get("id"));
    }

//    @PostMapping("/api/request/deleteByTitleMatch")
//    public void DeleteByTitleMatch(@RequestBody String s){
//        delete_task.deleteByTitlePattern(s);
//    }

}
