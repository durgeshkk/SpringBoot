package com.mvc.Services;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import com.mvc.Entity.Task;
import com.mvc.dao.TaskRepository;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("view_task")
public class view_Task {

    @Autowired
    TaskRepository repo;

    private static final Logger logger = LoggerFactory.getLogger(view_Task.class);

    public List<Task> getAllEntities() {
        logger.info("Request Received");
        return (List<Task>) repo.findAll();
    }

    public Optional<Task> getById(Long id){
        
        Optional.ofNullable(id)
        .orElseThrow(() -> new IllegalStateException("ID is NULL!"));

        Optional<Task> task = repo.findById(id);

        if(task.isPresent()){
            logger.info("Data Found in DB!");
        }else{
            logger.info("Data Not Found in DB!");
        }
        return task;
    }

    List<Task> allTasksEntities;
    @PostConstruct
    private void initAllTasksEntities(){
        allTasksEntities = getAllEntities();
    }

    public List<Task> getBeforeDueDate(LocalDate targetdate){
        logger.info("Returning List of Tasks before Due Date!");
        List<Task> filteredTasksEntities = allTasksEntities.stream()
            .filter(t -> ((t.getDue_date().isBefore(targetdate)) ? true : false))
            .collect(Collectors.toList()); 
        // For returning 2 different lists for before targetDate & after make use of 
        // Map<Boolean,List<Task>> in a single iteration.
        return filteredTasksEntities;
    }

    public List<Task> getTitlePatternMatching(String pattern){
        logger.info("Pattern to be searched "+pattern+" is found in : ");
        List<Task> filteredList = allTasksEntities.stream().
                filter(
                    t-> (t.getTitle().contains(pattern) ? true :false)
                ).collect(Collectors.toList());
        return filteredList;
    }
}
