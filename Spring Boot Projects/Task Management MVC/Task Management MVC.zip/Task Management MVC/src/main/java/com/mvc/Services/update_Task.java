package com.mvc.Services;

import com.mvc.Entity.Task;
import com.mvc.dao.TaskRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service("update_task")
public class update_Task {
    
    @Autowired
    TaskRepository repo;

    private static final Logger logger = LoggerFactory.getLogger(update_Task.class);


    public Task updateById(Task tasksEntitiesss){
        
        Optional.ofNullable(tasksEntitiesss.getId())
            .orElseThrow(() -> new IllegalStateException("Update Unsuccessful!! has No ID"));

        logger.info("ID is not NULL");

        Task task = repo.findById(tasksEntitiesss.getId())
                .map(t -> {
                    t.setCntr(tasksEntitiesss.getCntr());
                    t.setTitle(tasksEntitiesss.getTitle());
                    t.setTitle_description(tasksEntitiesss.getTitle_description());
                    t.setDue_date(tasksEntitiesss.getDue_date());
                    logger.info("ID Found, Data Saved to DB!");
                    return t;
                }).orElseGet(() -> {
                    logger.info("ID Not Found, New Data Saved to DB!");
                    return tasksEntitiesss;
                });

        repo.save(task);
        return task;
    }
}
        /*
        Integer id = task.getId();
        Optional<Task> optional = tManagementRepository.findById(id);

        if(optional.isPresent()){
            Task t = optional.get();
            t.setCntr(task.getCntr());
            t.setTitle(task.getTitle());
            t.setTitle_description(task.getTitle());
            t.setDueDate(task.getDueDate());
            return tManagementRepository.save(t);
        }else{

        }

        optional.ifPresentOrElse(Consumer<Task>, Runnable eRunnable);
        return task;*/
