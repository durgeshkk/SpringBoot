package com.mvc.Entity;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

import jakarta.persistence.*;
import java.time.LocalDate;

@Table(name = "taskentity")
@Data
@Entity
@JsonPropertyOrder({
        "id",
        "cntr",
        "title",
        "title_description",
        "due_date"
})
public class Task {

//    @Autowired
//    TaskRepository taskRepository;

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    @JsonProperty("id")
    private Long id;
//    @Column(name = "Task ID")

//    @Value("${your.cntr:10}")
    @JsonProperty("cntr")
    private Integer cntr;

//    @Value("task")
    @JsonProperty("title")
    private String title;

//    @Value("task_desc")
    @JsonProperty("title_description")
    private String title_description;

//    @Value("${your.dueDate:2023-01-01}")
    @Column(name = "due_date")
    @JsonProperty("due_date")
    @JsonFormat(pattern = "dd-MM-yyyy")
    private LocalDate due_date;

}
