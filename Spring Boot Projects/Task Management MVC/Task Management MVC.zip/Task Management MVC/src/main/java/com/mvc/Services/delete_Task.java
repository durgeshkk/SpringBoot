package com.mvc.Services;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mvc.Entity.Task;
import com.mvc.dao.TaskRepository;

@Service("delete_task")
public class delete_Task {
    
    @Autowired
    TaskRepository repo;
    
    private static final Logger logger = LoggerFactory.getLogger(delete_Task.class);

    public void deleteByIntId(Long id){
        Optional.ofNullable(repo.findById(id))
        .orElseThrow(() -> new IllegalStateException("ID is NULL!!"));

        Optional<Task> task = repo.findById(id);
        if(task.isPresent()){
            logger.info("ID Found to Delete");
            repo.deleteById(id);
            logger.info("ID Deleted");
        }else{
            logger.info("ID is not in DB");
        }
    }

//    @Autowired
//    private CRUDviewer v;
//
//    List<Task> allTasksEntities =  v.getAllEntities();
//    public void deleteByTitlePattern(String s){
//        List<Task> filterTasksEntities = allTasksEntities.stream()
//        .filter(t -> (t.getTitle().contains(s) ? true : false))
//        .collect(Collectors.toList());
//
//        logger.info("Deleting Filtered Tasks!!");
//        repo.deleteAll(filterTasksEntities);
//    }
//
    public void deleteAll(){
        logger.info("Deleting Complete DB Data!!");
        repo.deleteAll();
    }
}
