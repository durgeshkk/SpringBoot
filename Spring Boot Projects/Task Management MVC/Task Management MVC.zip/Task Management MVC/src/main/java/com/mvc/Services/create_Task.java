package com.mvc.Services;

import com.mvc.Entity.Task;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mvc.dao.TaskRepository;

import java.util.Optional;

@Service
public class create_Task {
    
    @Autowired
    public TaskRepository repo;

    private static final Logger logger = LoggerFactory.getLogger(create_Task.class);

    public void data_saved(Task tasksEntitiesss){
        // Use Consumer : Accepts one parameter returns nothing

        Optional.ofNullable(tasksEntitiesss.getId())
        .orElseThrow(() -> new IllegalArgumentException("Enter ID re"));

        logger.info("Data Saved to Database");
        repo.save(tasksEntitiesss);

        // if(task.getId() != null){
        // }else{
            // logger.info("Database Error");
            // Call DB Exception Error
        // }
    }
}
