package com.mvc.model;
import lombok.Data;
import jakarta.persistence.*;

@Data
@Table(name = "Person")
@Entity
public class Person {

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    @Column(name = "id")
    private Long id;

    @Column(name = "firstName")
    private String firstName;

    @Column(name = "lastName")
    private String lastName;

    @Column(name = "address")
    private String address;

    @Column(name = "phoneNo")
    private String phoneNo;

}
