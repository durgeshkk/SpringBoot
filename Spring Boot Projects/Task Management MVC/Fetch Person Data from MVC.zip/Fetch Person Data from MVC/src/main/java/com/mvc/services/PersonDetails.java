package com.mvc.services;

import com.mvc.apirequest.Requestid;
import com.mvc.dao.PersonRepository;
import com.mvc.model.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.HashMap;
import java.util.Optional;

@Service
public class PersonDetails {

    @Autowired
    private PersonRepository personRepository;

    public Optional<Person> searchById(Long id){
        return personRepository.findById(id);
    }
    public Optional<Person> searchByfirstName(String firstName){
        return Optional.ofNullable(personRepository.findByFirstName(firstName));
    }
    public Optional<Person> searchBylastName(String lastName){
        return Optional.ofNullable(personRepository.findByLastName(lastName));
    }

    public Optional<Person> searchPersonDetails(String request){
//        Way 1
        Optional<Person> person = Optional.ofNullable(personRepository.findByFirstName(request));
//                .or(()-> Optional.ofNullable(personRepository.findByLastName(request)));

        if(person.isPresent()){return person;}
        Optional<Person> person1 = Optional.ofNullable(personRepository.findByLastName(request));
        if(person1.isPresent()){return person1;}

//        Way 2
//        Optional<Person> person1 = Optional.ofNullable(request)
//                .flatMap(this::searchByfirstName)
//                .or(()-> Optional.ofNullable(request).flatMap(this::searchBylastName));

        return person;
//        return person1;
    }
}
