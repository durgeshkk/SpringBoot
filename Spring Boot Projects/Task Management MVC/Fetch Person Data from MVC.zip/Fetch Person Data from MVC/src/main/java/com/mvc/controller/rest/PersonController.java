package com.mvc.controller.rest;

import com.mvc.apirequest.Requestid;
import com.mvc.model.Person;
import com.mvc.services.PersonDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Optional;

@RestController
@Slf4j
@RequestMapping("/api")
public class PersonController {

    @Autowired
    private PersonDetails personDetails;

    @PostMapping("/search")
    public ResponseEntity<Person> searchPersonDetail(@RequestBody HashMap<String,String> mp){
        log.info("Lets get Started, Request Received");
        Optional<Person> person = personDetails.searchPersonDetails(mp.get("id"));
        log.info("Response for Request Received");
        if(person.isPresent()){
            return ResponseEntity.ok(person.get());
        }else{
            return ResponseEntity.badRequest().build();
        }
    }

}
