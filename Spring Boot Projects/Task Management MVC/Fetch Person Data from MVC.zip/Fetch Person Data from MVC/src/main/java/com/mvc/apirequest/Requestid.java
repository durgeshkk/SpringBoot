package com.mvc.apirequest;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

@JsonPropertyOrder({
        "id"
})
@Data
public class Requestid {
    @JsonProperty("id")
    private String id;
}
